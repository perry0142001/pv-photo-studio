const canvas = new fabric.Canvas('editorCanvas', {
  preserveObjectStacking: true, backgroundColor: '#ffffff',
  selection: true, fireRightClick: true
});
const $ = id => document.getElementById(id);
let undoStack = [], redoStack = [], restoring = false, saveTimer;
const status = msg => $('status').textContent = msg;

function saveHistory() {
  if (restoring) return;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    const state = JSON.stringify(canvas.toJSON(['selectable','evented']));
    if (undoStack[undoStack.length - 1] !== state) undoStack.push(state);
    if (undoStack.length > 40) undoStack.shift();
    redoStack = [];
    updateHistoryButtons();
  }, 180);
}
function updateHistoryButtons() {
  $('undoBtn').disabled = undoStack.length < 2;
  $('redoBtn').disabled = redoStack.length === 0;
}
function loadState(state) {
  restoring = true;
  canvas.loadFromJSON(state, () => {
    canvas.renderAll(); restoring = false; refreshLayers(); updateHistoryButtons();
  });
}
function undo() {
  clearTimeout(saveTimer);
  if (undoStack.length < 2) return;
  redoStack.push(undoStack.pop());
  loadState(undoStack[undoStack.length - 1]);
}
function redo() {
  if (!redoStack.length) return;
  const state = redoStack.pop(); undoStack.push(state); loadState(state);
}
canvas.on('object:added', () => { refreshLayers(); saveHistory(); });
canvas.on('object:removed', () => { refreshLayers(); saveHistory(); });
canvas.on('object:modified', () => { refreshLayers(); saveHistory(); });
canvas.on('selection:created', syncSelection);
canvas.on('selection:updated', syncSelection);
canvas.on('selection:cleared', () => { $('textValue').value = ''; refreshLayers(); });
canvas.on('text:changed', saveHistory);

function refreshLayers() {
  const list = $('layersList'); list.innerHTML = '';
  const objects = canvas.getObjects().slice().reverse();
  $('layerCount').textContent = objects.length;
  if (!objects.length) { list.innerHTML = '<p class="help">Your objects will appear here.</p>'; return; }
  objects.forEach((obj, reverseIndex) => {
    const realIndex = canvas.getObjects().indexOf(obj);
    const btn = document.createElement('button');
    btn.className = 'layer-item' + (canvas.getActiveObject() === obj ? ' selected' : '');
    const icon = document.createElement('span'); icon.className = 'layer-icon';
    icon.textContent = obj.type === 'textbox' || obj.type === 'i-text' || obj.type === 'text' ? 'T' : obj.type === 'image' ? '▧' : '◇';
    const name = document.createElement('span'); name.className = 'layer-name';
    name.textContent = obj.type === 'image' ? (obj.name || 'Image') : (obj.text || obj.name || (obj.type === 'rect' ? 'Rectangle' : obj.type));
    btn.append(icon, name);
    btn.addEventListener('click', () => { canvas.setActiveObject(obj); canvas.requestRenderAll(); syncSelection(); refreshLayers(); });
    btn.title = `Select layer ${objects.length - reverseIndex}`;
    list.appendChild(btn);
  });
}
function syncSelection() {
  const obj = canvas.getActiveObject();
  if (obj && (obj.type === 'textbox' || obj.type === 'i-text' || obj.type === 'text')) {
    $('textValue').value = obj.text || '';
    $('fontSize').value = obj.fontSize || 48;
    $('fontFamily').value = ['Arial','Georgia','Verdana','Tahoma','Impact'].includes(obj.fontFamily) ? obj.fontFamily : 'Arial';
    $('fillColor').value = safeHex(obj.fill, '#183b72');
    $('strokeColor').value = safeHex(obj.stroke, '#ffffff');
  }
  refreshLayers();
}
function safeHex(color, fallback) {
  if (typeof color === 'string' && /^#[0-9a-f]{6}$/i.test(color)) return color;
  return fallback;
}
function setTool(id) {
  document.querySelectorAll('.tool').forEach(b => b.classList.toggle('active', b.id === id));
}
function openFile() { $('fileInput').click(); }
$('openBtn').onclick = $('emptyOpenBtn').onclick = openFile;
$('fileInput').addEventListener('change', e => {
  const file = e.target.files[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => fabric.Image.fromURL(ev.target.result, img => {
    const maxW = 1200, maxH = 850, scale = Math.min(maxW / img.width, maxH / img.height, 1);
    canvas.setDimensions({ width: Math.round(img.width * scale), height: Math.round(img.height * scale) });
    canvas.clear(); canvas.backgroundColor = '#ffffff';
    img.set({ left: 0, top: 0, scaleX: scale, scaleY: scale, selectable: true, name: file.name });
    canvas.add(img); canvas.sendToBack(img); canvas.setActiveObject(img);
    $('emptyHint').style.display = 'none'; canvas.requestRenderAll();
    status(`Opened ${file.name}`); refreshLayers(); saveHistory();
  }, { crossOrigin: 'anonymous' });
  reader.readAsDataURL(file); e.target.value = '';
});
$('selectBtn').onclick = () => { canvas.selection = true; setTool('selectBtn'); status('Select an object and drag to move it.'); };
$('textBtn').onclick = () => { addText(); setTool('textBtn'); };
$('addTextBtn').onclick = addText;
function addText() {
  const text = $('textValue').value.trim() || 'Your text here';
  const obj = new fabric.Textbox(text, {
    left: Math.max(20, canvas.getWidth() * .1), top: Math.max(20, canvas.getHeight() * .1),
    width: Math.min(600, canvas.getWidth() * .8), fontSize: Math.min(48, canvas.getWidth() / 10),
    fontFamily: $('fontFamily').value || 'Arial', fill: $('fillColor').value,
    stroke: null, strokeWidth: 0, editable: true, name: 'Text'
  });
  canvas.add(obj); canvas.setActiveObject(obj); canvas.requestRenderAll(); syncSelection();
  status('Text added. Double-click the text on the canvas to edit it.');
}
$('applyTextBtn').onclick = () => {
  const obj = canvas.getActiveObject();
  if (!obj || !['textbox','i-text','text'].includes(obj.type)) { status('Select a text layer first.'); return; }
  obj.set({ text: $('textValue').value, fontSize: Math.max(8, Number($('fontSize').value) || 48), fontFamily: $('fontFamily').value, fill: $('fillColor').value });
  canvas.requestRenderAll(); saveHistory(); refreshLayers();
};
$('fontSize').addEventListener('change', () => $('applyTextBtn').click());
$('fontFamily').addEventListener('change', () => $('applyTextBtn').click());
$('fillColor').addEventListener('input', () => {
  const o = canvas.getActiveObject(); if (o && ['textbox','i-text','text'].includes(o.type)) { o.set('fill', $('fillColor').value); canvas.requestRenderAll(); saveHistory(); }
});
$('rectBtn').onclick = () => {
  const r = new fabric.Rect({ left: canvas.getWidth()*.2, top: canvas.getHeight()*.2, width: 220, height: 130, fill: $('fillColor').value, stroke: $('strokeColor').value, strokeWidth: 2, rx: 4, ry: 4 });
  canvas.add(r); canvas.setActiveObject(r); canvas.requestRenderAll(); setTool('rectBtn'); status('Shape added. Use the style controls to change its fill.'); refreshLayers();
};
$('deleteBtn').onclick = () => {
  const o = canvas.getActiveObject(); if (!o) return;
  if (o.type === 'activeSelection') o.forEachObject(x => canvas.remove(x)); else canvas.remove(o);
  canvas.discardActiveObject(); canvas.requestRenderAll(); refreshLayers(); status('Selected object deleted.');
};
$('upBtn').onclick = () => { const o=canvas.getActiveObject(); if(o){canvas.bringForward(o);canvas.requestRenderAll();refreshLayers();saveHistory();} };
$('downBtn').onclick = () => { const o=canvas.getActiveObject(); if(o){canvas.sendBackwards(o);canvas.requestRenderAll();refreshLayers();saveHistory();} };
$('undoBtn').onclick = undo; $('redoBtn').onclick = redo;
$('exportBtn').onclick = () => {
  canvas.discardActiveObject(); canvas.requestRenderAll();
  const link = document.createElement('a'); link.download = 'pv-photo-studio.png';
  link.href = canvas.toDataURL({ format: 'png', multiplier: 1 }); link.click();
  status('Exported PNG image.');
};
$('fitBtn').onclick = () => {
  const maxW = $('stage').clientWidth - 30, maxH = $('stage').clientHeight - 30;
  const scale = Math.min(maxW/canvas.getWidth(), maxH/canvas.getHeight(), 1);
  canvas.setZoom(scale); canvas.setWidth(canvas.getWidth()); canvas.requestRenderAll();
};
$('bgColor').addEventListener('input', () => { canvas.setBackgroundColor($('bgColor').value, canvas.renderAll.bind(canvas)); saveHistory(); });
$('bgBtn').onclick = () => $('bgColor').click();
$('cropHelpBtn').onclick = () => status('Crop: select an object and press “Crop to selection”. This starter crops the canvas to the selected object bounds.');
$('cropBtn').onclick = () => {
  const o = canvas.getActiveObject(); if (!o) { status('Select an object to crop around first.'); return; }
  const rect = o.getBoundingRect(true, true);
  const left = Math.max(0, rect.left), top = Math.max(0, rect.top);
  const right = Math.min(canvas.getWidth(), rect.left + rect.width), bottom = Math.min(canvas.getHeight(), rect.top + rect.height);
  if (right <= left || bottom <= top) { status('Selected object is outside the canvas.'); return; }
  const data = canvas.toDataURL({ format: 'png', left, top, width: right-left, height: bottom-top, multiplier: 1 });
  fabric.Image.fromURL(data, img => {
    canvas.clear(); canvas.setDimensions({width:Math.round(right-left),height:Math.round(bottom-top)});
    img.set({left:0,top:0,selectable:true,name:'Cropped image'}); canvas.add(img); canvas.setActiveObject(img);
    canvas.renderAll(); refreshLayers(); saveHistory(); status('Canvas cropped to selected object bounds.');
  });
};
$('applyFiltersBtn').onclick = () => {
  const obj = canvas.getActiveObject();
  if (!obj || obj.type !== 'image') { status('Select an image layer first.'); return; }
  const b = Number($('brightness').value), c = Number($('contrast').value);
  obj.filters = [new fabric.Image.filters.Brightness({ brightness: b }), new fabric.Image.filters.Contrast({ contrast: c })];
  obj.applyFilters(); canvas.requestRenderAll(); saveHistory(); status('Image adjustments applied.');
};
window.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); undo(); }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); }
  if ((e.key === 'Delete' || e.key === 'Backspace') && !['INPUT','TEXTAREA'].includes(document.activeElement.tagName)) { $('deleteBtn').click(); }
});
canvas.setDimensions({width:1000,height:650});
canvas.backgroundColor = '#ffffff';
canvas.renderAll(); refreshLayers();
undoStack.push(JSON.stringify(canvas.toJSON(['selectable','evented']))); updateHistoryButtons();
status('Ready. Open a photo to begin editing.');
